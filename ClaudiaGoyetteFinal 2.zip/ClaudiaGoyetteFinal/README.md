Artist statement - Final project
